/* =============================================
   CODE QUEST — App Logic (Lite Orange Theme)
   ============================================= */

// ========== SPA ROUTER ==========
function navigateTo(page) {
  window.location.hash = page;
}

function handleRoute() {
  const hash = window.location.hash.slice(1) || 'home';
  const sections = document.querySelectorAll('.page-section');
  const navItems = document.querySelectorAll('.nav-item');

  sections.forEach(s => s.classList.remove('active'));
  navItems.forEach(n => n.classList.remove('active'));

  const target = document.getElementById('page-' + hash);
  if (target) {
    target.classList.add('active');
    const navTarget = document.querySelector(`[data-page="${hash}"]`);
    if (navTarget) navTarget.classList.add('active');
  }

  // Close mobile menu
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('open');

  // Trigger page-specific init
  if (hash === 'home') initHome();
  if (hash === 'leaderboard') initLeaderboard();
  if (hash === 'streak') initStreak();
  if (hash === 'chat') initChat();
}

window.addEventListener('hashchange', handleRoute);
window.addEventListener('DOMContentLoaded', () => {
  handleRoute();
  initNav();
  initInlineHandlers();
  initGame();
  initAIGenerator();
  initAITeacher();
  initAuth();
});

// ========== BIND ALL EVENT HANDLERS (replaces inline onclick) ==========
function initInlineHandlers() {
  // Hero buttons
  document.getElementById('heroStartBtn').addEventListener('click', () => navigateTo('languages'));
  document.getElementById('heroPlayBtn').addEventListener('click', () => navigateTo('game'));

  // Challenge level buttons
  document.querySelectorAll('.challenge-level-btn').forEach(btn => {
    btn.addEventListener('click', () => loadChallenge(btn.dataset.level));
  });

  // Battle join buttons
  document.querySelectorAll('.battle-join-btn').forEach(btn => {
    btn.addEventListener('click', () => startBattle(btn.dataset.battle));
  });

  // Quick match
  document.getElementById('quickMatchBtn').addEventListener('click', () => startBattle('Quick Match'));

  // Cancel battle
  document.getElementById('cancelBattleBtn').addEventListener('click', cancelBattle);

  // Ask AI Teacher from game page
  document.getElementById('askAiBtn').addEventListener('click', () => navigateTo('ai-teacher'));

  // Quick prompt tags (AI Generator)
  document.querySelectorAll('.quick-prompt-tag').forEach(tag => {
    tag.addEventListener('click', () => setPrompt(tag.dataset.prompt));
  });

  // Teacher topic buttons
  document.querySelectorAll('.teacher-topic-btn').forEach(btn => {
    btn.addEventListener('click', () => askTeacher(btn.dataset.question));
  });
}

// ========== NAVIGATION ==========
function initNav() {
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
      const page = item.dataset.page;
      if (page) navigateTo(page);
    });
  });

  // Mobile menu
  const menuBtn = document.getElementById('mobileMenuBtn');
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebarOverlay');

  menuBtn.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    overlay.classList.toggle('open');
  });
  overlay.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlay.classList.remove('open');
  });
}

// ========== HOME PAGE ==========
let heroInitialized = false;

function initHome() {
  // Hero code typing — only once
  if (!heroInitialized) {
    heroInitialized = true;
    const codeBlock = document.getElementById('heroCodeBlock');
    const codeLines = [
      '<span class="comment"># Welcome to Code Quest 🔥</span>',
      '<span class="keyword">class</span> <span class="function">Coder</span>:',
      '    <span class="keyword">def</span> <span class="function">__init__</span>(self):',
      '        self.name = <span class="string">"You"</span>',
      '        self.xp = <span class="number">0</span>',
      '        self.level = <span class="number">1</span>',
      '',
      '    <span class="keyword">def</span> <span class="function">learn</span>(self, lang):',
      '        self.xp += <span class="number">100</span>',
      '        <span class="function">print</span>(<span class="string">f"Learning {lang}!"</span>)',
      '',
      'coder = <span class="function">Coder</span>()',
      'coder.<span class="function">learn</span>(<span class="string">"Python"</span>)',
    ];

    codeBlock.innerHTML = '';
    codeLines.forEach((line, i) => {
      setTimeout(() => {
        const div = document.createElement('div');
        div.className = 'code-line';
        div.innerHTML = line || '&nbsp;';
        div.style.animationDelay = `${i * 0.08}s`;
        codeBlock.appendChild(div);
      }, i * 120);
    });
  }

  // Stat counters animation — animate every time home is shown
  animateStatCounters();
}

function animateStatCounters() {
  document.querySelectorAll('.stat-number[data-target]').forEach(el => {
    const target = parseInt(el.dataset.target);
    const suffix = el.dataset.suffix || '';
    // Reset to 0 first
    el.textContent = '0' + suffix;
    let current = 0;
    const step = Math.ceil(target / 50);
    const startTime = performance.now();

    function tick() {
      current += step;
      if (current >= target) {
        current = target;
        el.textContent = current.toLocaleString() + suffix;
        return;
      }
      el.textContent = current.toLocaleString() + suffix;
      requestAnimationFrame(tick);
    }
    // Small delay so user sees the 0 → target animation
    setTimeout(() => requestAnimationFrame(tick), 300);
  });
}

// ========== LANGUAGES PAGE ==========
document.querySelectorAll('.lang-card').forEach(card => {
  card.addEventListener('click', () => {
    const lang = card.dataset.lang;
    document.querySelectorAll('.lesson-panel').forEach(p => p.classList.remove('active'));
    const panel = document.getElementById('lesson-' + lang);
    if (panel) {
      if (panel.classList.contains('active')) {
        panel.classList.remove('active');
      } else {
        panel.classList.add('active');
      }
    }
  });
});

// ========== PLAY GAME PAGE ==========
const challenges = {
  javascript: {
    level1: { title: '🎯 JavaScript Level 1: Hello World', desc: 'Print Hello World to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Hello World.', starter: 'function printHello() {\n    // Code Quest Lesson 1\n}', hint: '💡 Hint: Think about Code Quest lessons on Hello World', xp: 20, tags: ['JS', 'Level 1', '⭐ 20 XP'], tests: [{ label: 'Verify logic for Hello World', expected: true }], funcName: 'test_func' },
    level2: { title: '🎯 JavaScript Level 2: Sum Numbers', desc: 'Add two numbers to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Sum Numbers.', starter: 'function add(a, b) {\n    // Code Quest Lesson 2\n}', hint: '💡 Hint: Think about Code Quest lessons on Sum Numbers', xp: 40, tags: ['JS', 'Level 2', '⭐ 40 XP'], tests: [{ label: 'Verify logic for Sum Numbers', expected: true }], funcName: 'test_func' },
    level3: { title: '🎯 JavaScript Level 3: Data Types', desc: 'Return an integer to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Data Types.', starter: 'function getInt() {\n    // Code Quest Lesson 3\n}', hint: '💡 Hint: Think about Code Quest lessons on Data Types', xp: 60, tags: ['JS', 'Level 3', '⭐ 60 XP'], tests: [{ label: 'Verify logic for Data Types', expected: true }], funcName: 'test_func' },
    level4: { title: '🎯 JavaScript Level 4: Strings', desc: 'Return combined text to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Strings.', starter: 'function combine(a, b) {\n    // Code Quest Lesson 4\n}', hint: '💡 Hint: Think about Code Quest lessons on Strings', xp: 80, tags: ['JS', 'Level 4', '⭐ 80 XP'], tests: [{ label: 'Verify logic for Strings', expected: true }], funcName: 'test_func' },
    level5: { title: '🎯 JavaScript Level 5: Even or Odd', desc: 'Return true if even to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Even or Odd.', starter: 'function isEven(n) {\n    // Code Quest Lesson 5\n}', hint: '💡 Hint: Think about Code Quest lessons on Even or Odd', xp: 100, tags: ['JS', 'Level 5', '⭐ 100 XP'], tests: [{ label: 'Verify logic for Even or Odd', expected: true }], funcName: 'test_func' },
    level6: { title: '🎯 JavaScript Level 6: Conditionals', desc: 'Return max of two to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Conditionals.', starter: 'function max(a, b) {\n    // Code Quest Lesson 6\n}', hint: '💡 Hint: Think about Code Quest lessons on Conditionals', xp: 120, tags: ['JS', 'Level 6', '⭐ 120 XP'], tests: [{ label: 'Verify logic for Conditionals', expected: true }], funcName: 'test_func' },
    level7: { title: '🎯 JavaScript Level 7: Loops', desc: 'Sum up to n to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Loops.', starter: 'function sumToN(n) {\n    // Code Quest Lesson 7\n}', hint: '💡 Hint: Think about Code Quest lessons on Loops', xp: 140, tags: ['JS', 'Level 7', '⭐ 140 XP'], tests: [{ label: 'Verify logic for Loops', expected: true }], funcName: 'test_func' },
    level8: { title: '🎯 JavaScript Level 8: Arrays/Lists', desc: 'Reverse an array to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Arrays/Lists.', starter: 'function rev(arr) {\n    // Code Quest Lesson 8\n}', hint: '💡 Hint: Think about Code Quest lessons on Arrays/Lists', xp: 160, tags: ['JS', 'Level 8', '⭐ 160 XP'], tests: [{ label: 'Verify logic for Arrays/Lists', expected: true }], funcName: 'test_func' },
    level9: { title: '🎯 JavaScript Level 9: Functions', desc: 'Call a function to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Functions.', starter: 'function callOther() {\n    // Code Quest Lesson 9\n}', hint: '💡 Hint: Think about Code Quest lessons on Functions', xp: 180, tags: ['JS', 'Level 9', '⭐ 180 XP'], tests: [{ label: 'Verify logic for Functions', expected: true }], funcName: 'test_func' },
    level10: { title: '🎯 JavaScript Level 10: Algorithms', desc: 'Fibonacci sequence to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Algorithms.', starter: 'function fib(n) {\n    // Code Quest Lesson 10\n}', hint: '💡 Hint: Think about Code Quest lessons on Algorithms', xp: 200, tags: ['JS', 'Level 10', '⭐ 200 XP'], tests: [{ label: 'Verify logic for Algorithms', expected: true }], funcName: 'test_func' }
  },
  python: {
    level1: { title: '🎯 Python Level 1: Hello World', desc: 'Print Hello World to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Hello World.', starter: 'def print_hello():\n    # Code Quest Lesson 1\n    pass', hint: '💡 Hint: Think about Code Quest lessons on Hello World', xp: 20, tags: ['PY', 'Level 1', '⭐ 20 XP'], tests: [{ label: 'Verify logic for Hello World', expected: true }], funcName: 'test_func' },
    level2: { title: '🎯 Python Level 2: Sum Numbers', desc: 'Add two numbers to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Sum Numbers.', starter: 'def add(a, b):\n    # Code Quest Lesson 2\n    pass', hint: '💡 Hint: Think about Code Quest lessons on Sum Numbers', xp: 40, tags: ['PY', 'Level 2', '⭐ 40 XP'], tests: [{ label: 'Verify logic for Sum Numbers', expected: true }], funcName: 'test_func' },
    level3: { title: '🎯 Python Level 3: Data Types', desc: 'Return an integer to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Data Types.', starter: 'def get_int():\n    \n    pass', hint: '💡 Hint: Think about Code Quest lessons on Data Types', xp: 60, tags: ['PY', 'Level 3', '⭐ 60 XP'], tests: [{ label: 'Verify logic for Data Types', expected: true }], funcName: 'test_func' },
    level4: { title: '🎯 Python Level 4: Strings', desc: 'Return combined text to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Strings.', starter: 'def combine(a, b):\n    \n    pass', hint: '💡 Hint: Think about Code Quest lessons on Strings', xp: 80, tags: ['PY', 'Level 4', '⭐ 80 XP'], tests: [{ label: 'Verify logic for Strings', expected: true }], funcName: 'test_func' },
    level5: { title: '🎯 Python Level 5: Even or Odd', desc: 'Return true if even to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Even or Odd.', starter: 'def is_even(n):\n    \n    pass', hint: '💡 Hint: Think about Code Quest lessons on Even or Odd', xp: 100, tags: ['PY', 'Level 5', '⭐ 100 XP'], tests: [{ label: 'Verify logic for Even or Odd', expected: true }], funcName: 'test_func' },
    level6: { title: '🎯 Python Level 6: Conditionals', desc: 'Return max of two to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Conditionals.', starter: 'def max(a, b):\n    \n    pass', hint: '💡 Hint: Think about Code Quest lessons on Conditionals', xp: 120, tags: ['PY', 'Level 6', '⭐ 120 XP'], tests: [{ label: 'Verify logic for Conditionals', expected: true }], funcName: 'test_func' },
    level7: { title: '🎯 Python Level 7: Loops', desc: 'Sum up to n to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Loops.', starter: 'def sum_to_n(n):\n    \n    pass', hint: '💡 Hint: Think about Code Quest lessons on Loops', xp: 140, tags: ['PY', 'Level 7', '⭐ 140 XP'], tests: [{ label: 'Verify logic for Loops', expected: true }], funcName: 'test_func' },
    level8: { title: '🎯 Python Level 8: Arrays/Lists', desc: 'Reverse an array to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Arrays/Lists.', starter: 'def rev(arr):\n    \n    pass', hint: '💡 Hint: Think about Code Quest lessons on Arrays/Lists', xp: 160, tags: ['PY', 'Level 8', '⭐ 160 XP'], tests: [{ label: 'Verify logic for Arrays/Lists', expected: true }], funcName: 'test_func' },
    level9: { title: '🎯 Python Level 9: Functions', desc: 'Call a function to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Functions.', starter: 'def call_other():\n    \n    pass', hint: '💡 Hint: Think about Code Quest lessons on Functions', xp: 180, tags: ['PY', 'Level 9', '⭐ 180 XP'], tests: [{ label: 'Verify logic for Functions', expected: true }], funcName: 'test_func' },
    level10: { title: '🎯 Python Level 10: Algorithms', desc: 'Fibonacci sequence to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Algorithms.', starter: 'def fib(n):\n    \n    pass', hint: '💡 Hint: Think about Code Quest lessons on Algorithms', xp: 200, tags: ['PY', 'Level 10', '⭐ 200 XP'], tests: [{ label: 'Verify logic for Algorithms', expected: true }], funcName: 'test_func' }
  },
  html: {
    level1: { title: '🎯 HTML Level 1: Hello World', desc: 'Print Hello World to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Hello World.', starter: '<!-- Add an h1 -->\n', hint: '💡 Hint: Think about Code Quest lessons on Hello World', xp: 20, tags: ['HTML', 'Level 1', '⭐ 20 XP'], tests: [{ label: 'Verify logic for Hello World', expected: true }], funcName: 'test_func' },
    level2: { title: '🎯 HTML Level 2: Sum Numbers', desc: 'Add two numbers to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Sum Numbers.', starter: '<!-- Add a button -->\n', hint: '💡 Hint: Think about Code Quest lessons on Sum Numbers', xp: 40, tags: ['HTML', 'Level 2', '⭐ 40 XP'], tests: [{ label: 'Verify logic for Sum Numbers', expected: true }], funcName: 'test_func' },
    level3: { title: '🎯 HTML Level 3: Data Types', desc: 'Return an integer to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Data Types.', starter: '<!-- Add an image -->\n', hint: '💡 Hint: Think about Code Quest lessons on Data Types', xp: 60, tags: ['HTML', 'Level 3', '⭐ 60 XP'], tests: [{ label: 'Verify logic for Data Types', expected: true }], funcName: 'test_func' },
    level4: { title: '🎯 HTML Level 4: Strings', desc: 'Return combined text to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Strings.', starter: '<!-- Add a paragraph -->\n', hint: '💡 Hint: Think about Code Quest lessons on Strings', xp: 80, tags: ['HTML', 'Level 4', '⭐ 80 XP'], tests: [{ label: 'Verify logic for Strings', expected: true }], funcName: 'test_func' },
    level5: { title: '🎯 HTML Level 5: Even or Odd', desc: 'Return true if even to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Even or Odd.', starter: '<!-- Add a link -->\n', hint: '💡 Hint: Think about Code Quest lessons on Even or Odd', xp: 100, tags: ['HTML', 'Level 5', '⭐ 100 XP'], tests: [{ label: 'Verify logic for Even or Odd', expected: true }], funcName: 'test_func' },
    level6: { title: '🎯 HTML Level 6: Conditionals', desc: 'Return max of two to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Conditionals.', starter: '<!-- Add a list -->\n', hint: '💡 Hint: Think about Code Quest lessons on Conditionals', xp: 120, tags: ['HTML', 'Level 6', '⭐ 120 XP'], tests: [{ label: 'Verify logic for Conditionals', expected: true }], funcName: 'test_func' },
    level7: { title: '🎯 HTML Level 7: Loops', desc: 'Sum up to n to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Loops.', starter: '<!-- Add a nav bar -->\n', hint: '💡 Hint: Think about Code Quest lessons on Loops', xp: 140, tags: ['HTML', 'Level 7', '⭐ 140 XP'], tests: [{ label: 'Verify logic for Loops', expected: true }], funcName: 'test_func' },
    level8: { title: '🎯 HTML Level 8: Arrays/Lists', desc: 'Reverse an array to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Arrays/Lists.', starter: '<!-- Add a table -->\n', hint: '💡 Hint: Think about Code Quest lessons on Arrays/Lists', xp: 160, tags: ['HTML', 'Level 8', '⭐ 160 XP'], tests: [{ label: 'Verify logic for Arrays/Lists', expected: true }], funcName: 'test_func' },
    level9: { title: '🎯 HTML Level 9: Functions', desc: 'Call a function to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Functions.', starter: '<!-- Add a form -->\n', hint: '💡 Hint: Think about Code Quest lessons on Functions', xp: 180, tags: ['HTML', 'Level 9', '⭐ 180 XP'], tests: [{ label: 'Verify logic for Functions', expected: true }], funcName: 'test_func' },
    level10: { title: '🎯 HTML Level 10: Algorithms', desc: 'Fibonacci sequence to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Algorithms.', starter: '<!-- Add a div container -->\n', hint: '💡 Hint: Think about Code Quest lessons on Algorithms', xp: 200, tags: ['HTML', 'Level 10', '⭐ 200 XP'], tests: [{ label: 'Verify logic for Algorithms', expected: true }], funcName: 'test_func' }
  },
  c: {
    level1: { title: '🎯 C Level 1: Hello World', desc: 'Print Hello World to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Hello World.', starter: 'int main() {\n    // Code Quest Lesson 1\n    return 0;\n}', hint: '💡 Hint: Think about Code Quest lessons on Hello World', xp: 20, tags: ['C', 'Level 1', '⭐ 20 XP'], tests: [{ label: 'Verify logic for Hello World', expected: true }], funcName: 'test_func' },
    level2: { title: '🎯 C Level 2: Sum Numbers', desc: 'Add two numbers to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Sum Numbers.', starter: 'int add(int a, int b) {\n}', hint: '💡 Hint: Think about Code Quest lessons on Sum Numbers', xp: 40, tags: ['C', 'Level 2', '⭐ 40 XP'], tests: [{ label: 'Verify logic for Sum Numbers', expected: true }], funcName: 'test_func' },
    level3: { title: '🎯 C Level 3: Data Types', desc: 'Return an integer to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Data Types.', starter: 'int get_int() {\n}', hint: '💡 Hint: Think about Code Quest lessons on Data Types', xp: 60, tags: ['C', 'Level 3', '⭐ 60 XP'], tests: [{ label: 'Verify logic for Data Types', expected: true }], funcName: 'test_func' },
    level4: { title: '🎯 C Level 4: Strings', desc: 'Return combined text to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Strings.', starter: 'char* combine() {\n}', hint: '💡 Hint: Think about Code Quest lessons on Strings', xp: 80, tags: ['C', 'Level 4', '⭐ 80 XP'], tests: [{ label: 'Verify logic for Strings', expected: true }], funcName: 'test_func' },
    level5: { title: '🎯 C Level 5: Even or Odd', desc: 'Return true if even to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Even or Odd.', starter: 'int is_even(int n) {\n}', hint: '💡 Hint: Think about Code Quest lessons on Even or Odd', xp: 100, tags: ['C', 'Level 5', '⭐ 100 XP'], tests: [{ label: 'Verify logic for Even or Odd', expected: true }], funcName: 'test_func' },
    level6: { title: '🎯 C Level 6: Conditionals', desc: 'Return max of two to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Conditionals.', starter: 'int max(int a, int b) {\n}', hint: '💡 Hint: Think about Code Quest lessons on Conditionals', xp: 120, tags: ['C', 'Level 6', '⭐ 120 XP'], tests: [{ label: 'Verify logic for Conditionals', expected: true }], funcName: 'test_func' },
    level7: { title: '🎯 C Level 7: Loops', desc: 'Sum up to n to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Loops.', starter: 'int sum_to_n(int n) {\n}', hint: '💡 Hint: Think about Code Quest lessons on Loops', xp: 140, tags: ['C', 'Level 7', '⭐ 140 XP'], tests: [{ label: 'Verify logic for Loops', expected: true }], funcName: 'test_func' },
    level8: { title: '🎯 C Level 8: Arrays/Lists', desc: 'Reverse an array to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Arrays/Lists.', starter: 'void rev(int* arr) {\n}', hint: '💡 Hint: Think about Code Quest lessons on Arrays/Lists', xp: 160, tags: ['C', 'Level 8', '⭐ 160 XP'], tests: [{ label: 'Verify logic for Arrays/Lists', expected: true }], funcName: 'test_func' },
    level9: { title: '🎯 C Level 9: Functions', desc: 'Call a function to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Functions.', starter: 'void call_other() {\n}', hint: '💡 Hint: Think about Code Quest lessons on Functions', xp: 180, tags: ['C', 'Level 9', '⭐ 180 XP'], tests: [{ label: 'Verify logic for Functions', expected: true }], funcName: 'test_func' },
    level10: { title: '🎯 C Level 10: Algorithms', desc: 'Fibonacci sequence to advance to the next level in Code Quest! Remember the interactive lessons.', examples: 'Follow standard syntax for Algorithms.', starter: 'int fib(int n) {\n}', hint: '💡 Hint: Think about Code Quest lessons on Algorithms', xp: 200, tags: ['C', 'Level 10', '⭐ 200 XP'], tests: [{ label: 'Verify logic for Algorithms', expected: true }], funcName: 'test_func' }
  }
};

let currentLang = 'javascript';
let currentLevel = 'level1';
let gameTimerInterval = null;
let gameTimeLeft = 300;

function loadChallenge(level, lang = null) {
  if (lang) currentLang = lang;
  currentLevel = level;

  if (!challenges[currentLang] || !challenges[currentLang][currentLevel]) return;
  const ch = challenges[currentLang][currentLevel];

  document.getElementById('challengeTitle').textContent = ch.title;
  document.getElementById('challengeDesc').innerHTML = ch.desc +
    '<ul style="margin:12px 0;padding-left:20px;color:var(--text-secondary);line-height:2;"><li>Input: Check the examples below</li><li>Output: Return the correct result</li></ul>';
  document.getElementById('challengeExamples').innerHTML = '<strong style="color:var(--primary);">Examples:</strong><br>' + ch.examples.replace(/\n/g, '<br>');
  document.getElementById('codeEditor').value = ch.starter;
  document.getElementById('gameXP').textContent = '+' + ch.xp + ' XP';
  document.getElementById('codeOutput').textContent = 'Output will appear here...';

  // Reset Buttons
  document.getElementById('submitBtn').classList.remove('hidden');
  document.getElementById('nextChallengeBtn').classList.add('hidden');

  // Tags
  const tagColors = ['tag-orange', 'tag-green', 'tag-yellow'];
  document.getElementById('challengeTags').innerHTML = ch.tags.map((t, i) =>
    `<span class="tag ${tagColors[i] || 'tag-orange'}">${t}</span>`
  ).join('');

  // Level buttons
  const container = document.getElementById('levelButtonsContainer');
  if (container) {
    let ht = '';
    for (let i = 1; i <= 10; i++) {
      const lvlCode = 'level' + i;
      const isActive = (lvlCode === currentLevel);
      const btnClass = isActive ? 'btn-primary active' : 'btn-secondary';
      ht += `<button class="btn ${btnClass} challenge-level-btn" style="padding: 4px 10px; font-size: 13px;" data-level="${lvlCode}">Lvl ${i}</button>`;
    }
    container.innerHTML = ht;

    // Attach listeners
    container.querySelectorAll('.challenge-level-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        loadChallenge(btn.dataset.level);
      });
    });
  }

  // Language buttons
  document.querySelectorAll('.challenge-lang-btn').forEach(btn => {
    btn.classList.remove('active', 'btn-primary');
    btn.classList.add('btn-secondary');
    if (btn.dataset.lang === currentLang) {
      btn.classList.add('active', 'btn-primary');
      btn.classList.remove('btn-secondary');
    }
  });

  // Reset timer
  const lvlNum = parseInt(level.replace('level', '')) || 1;
  gameTimeLeft = 300 - (lvlNum * 15);
  updateTimerDisplay();
  if (gameTimerInterval) clearInterval(gameTimerInterval);
  gameTimerInterval = setInterval(() => {
    gameTimeLeft--;
    updateTimerDisplay();
    if (gameTimeLeft <= 0) {
      clearInterval(gameTimerInterval);
      document.getElementById('codeOutput').innerHTML = '<span style="color:var(--red);">⏰ Time\'s up! Try again.</span>';
    }
  }, 1000);
}

function updateTimerDisplay() {
  const m = String(Math.floor(gameTimeLeft / 60)).padStart(2, '0');
  const s = String(gameTimeLeft % 60).padStart(2, '0');
  document.getElementById('gameTimer').textContent = m + ':' + s;
}

/**
 * Runs the user's code against the test cases for the current challenge.
 * Returns { results: [{passed, label, error}], allPassed: bool }
 */
async function runTests(code, challenge) {
  const results = [];
  let allPassed = true;
  let consoleLogs = [];

  const mockConsoleLog = (...args) => consoleLogs.push(args.map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' '));

  if (currentLang === 'javascript') {
    mockConsoleLog("Executing in simulated JavaScript environment...");
    for (let i = 0; i < challenge.tests.length; i++) {
      const test = challenge.tests[i];
      let passed = false;
      let lowerTitle = challenge.title.toLowerCase();
      if (code.includes('return') && code.includes('+') && lowerTitle.includes('sum')) passed = true;
      else if (code.includes('reverse') && lowerTitle.includes('reverse')) passed = true;
      else if ((code.includes('Fizz') || code.includes('%')) && lowerTitle.includes('fizz')) passed = true;
      else if (code.trim().length > 20 && code !== challenge.starter) passed = true;

      const msg = passed ? (test.expected ? JSON.stringify(test.expected) : "Success") : "Logic Error: code does not meet requirements.";
      results.push({ passed, label: test.label || "JS Execution Check", got: msg, expected: test.expected ? JSON.stringify(test.expected) : "Successful execution" });
      if (!passed) allPassed = false;
    }
    return { results, allPassed, consoleLogs };
  }

  else if (currentLang === 'python') {
    mockConsoleLog("Executing in simulated Python environment...");
    for (let i = 0; i < challenge.tests.length; i++) {
      const test = challenge.tests[i];
      let passed = false;
      let lowerTitle = challenge.title.toLowerCase();
      if (code.includes('return') && code.includes('+') && lowerTitle.includes('sum')) passed = true;
      else if (code.includes('for') && code.includes('in') && lowerTitle.includes('comprehension')) passed = true;
      else if (code.includes('fib(n-1)') && lowerTitle.includes('fibonacci')) passed = true;
      else if (code.trim().length > 20 && code !== challenge.starter) passed = true;

      const msg = passed ? (test.expected ? JSON.stringify(test.expected) : "Success") : "Syntax or Logic Error.";
      results.push({ passed, label: test.label || "Python Execution Check", got: msg, expected: test.expected ? JSON.stringify(test.expected) : "Successful execution" });
      if (!passed) allPassed = false;
    }
    return { results, allPassed, consoleLogs };
  }

  else if (currentLang === 'html') {
    mockConsoleLog("Rendering HTML in virtual DOM...");
    const container = document.createElement('div');
    container.innerHTML = code;
    for (let i = 0; i < challenge.tests.length; i++) {
      const test = challenge.tests[i];
      try {
        let passed = false; let got = "Missing target";
        let lowerTitle = challenge.title.toLowerCase();
        if (lowerTitle.includes('button') && container.querySelector('button')) { passed = true; got = "<button> found"; }
        else if (lowerTitle.includes('link') && container.querySelector('a')) { passed = true; got = "<a> found"; }
        else if (lowerTitle.includes('form') && container.querySelector('form')) { passed = true; got = "<form> found"; }
        else if (code.length > 5 && lowerTitle.includes('html')) { passed = true; got = "HTML Parsed"; }
        results.push({ passed, label: test.label || "Check HTML Structure", got: passed ? got : "Missing expected tags.", expected: "Correct HTML Element" });
        if (!passed) allPassed = false;
      } catch (err) {
        results.push({ passed: false, label: test.label, error: err.message });
        allPassed = false;
      }
    }
    return { results, allPassed, consoleLogs };
  }

  else if (currentLang === 'c') {
    mockConsoleLog("Executing in simulated C environment...");
    for (let i = 0; i < challenge.tests.length; i++) {
      const test = challenge.tests[i];
      let passed = false;
      let lowerTitle = challenge.title.toLowerCase();
      if (code.includes('printf') && lowerTitle.includes('print')) passed = true;
      else if (code.includes('return') && code.includes('+') && lowerTitle.includes('sum')) passed = true;
      else if (code.includes('*a') && code.includes('*b') && lowerTitle.includes('pointer')) passed = true;
      else if (code.trim().length > 20 && code !== challenge.starter) passed = true;
      const msg = passed ? "Compiled and run successfully" : "Compilation or Logic Error";
      results.push({ passed, label: test.label || "C Execution Check", got: msg, expected: "Successful execution" });
      if (!passed) allPassed = false;
    }
    return { results, allPassed, consoleLogs };
  }

  return { results, allPassed, consoleLogs };
}

let loadChallengeEventAttached = false;

function initGame() {
  // Wait to attach test buttons until page load
  loadChallenge(currentLevel, currentLang);

  if (loadChallengeEventAttached) return;
  loadChallengeEventAttached = true;

  // Language buttons
  document.querySelectorAll('.challenge-lang-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      loadChallenge('level1', btn.dataset.lang);
    });
  });


  // TEST button — runs all tests and shows individual results
  document.getElementById('testBtn').addEventListener('click', () => {
    const code = document.getElementById('codeEditor').value;
    const ch = challenges[currentLang][currentLevel];
    const output = document.getElementById('codeOutput');

    output.innerHTML = '<span style="color:var(--primary);">▶ Execution Engine Started...</span><br><br>';

    // Add small delay for visual feedback
    setTimeout(async () => {
      const { results, allPassed, consoleLogs } = await runTests(code, ch);
      let html = '<span style="color:var(--primary);font-weight:600;">📋 Test Results:</span><br><br>';

      results.forEach((r, i) => {
        if (r.passed) {
          html += `<span style="color:var(--green);">✅ Test ${i + 1}: Passed</span> — ${r.label}<br>`;
        } else if (r.error) {
          html += `<span style="color:var(--red);">❌ Test ${i + 1}: Error</span> — ${r.label}<br>`;
          html += `<span style="color:var(--text-muted);font-size:12px;">   Error: ${r.error}</span><br>`;
        } else {
          html += `<span style="color:var(--red);">❌ Test ${i + 1}: Failed</span> — ${r.label}<br>`;
          html += `<span style="color:var(--text-muted);font-size:12px;">   Got: ${r.got}</span><br>`;
        }
      });

      const passedCount = results.filter(r => r.passed).length;
      html += `<br><span style="color:${allPassed ? 'var(--green)' : 'var(--yellow)'};font-weight:600;">${passedCount}/${results.length} tests passed</span>`;

      if (consoleLogs && consoleLogs.length > 0) {
        html += '<br><br><span style="color:var(--text-secondary);font-weight:600;">📝 Console Output:</span><br>';
        html += `<div style="background: rgba(0,0,0,0.1); padding: 8px; border-radius: 4px; font-family: monospace; color: var(--text-muted); margin-top: 8px; white-space: pre-wrap;">`;
        html += consoleLogs.join('<br>') + '</div>';
      }

      if (!allPassed) {
        html += '<br><span style="color:var(--text-muted);font-size:12px;">Fix the failing tests and try again.</span>';
      }

      output.innerHTML = html;
    }, 300);
  });

  // SUBMIT button — runs all tests, awards XP only if all pass
  document.getElementById('submitBtn').addEventListener('click', () => {
    const code = document.getElementById('codeEditor').value;
    const ch = challenges[currentLang][currentLevel];
    const output = document.getElementById('codeOutput');

    output.innerHTML = '<span style="color:var(--primary);">🚀 Execution Engine Started...</span>';

    setTimeout(async () => {
      const { results, allPassed, consoleLogs } = await runTests(code, ch);

      if (allPassed) {
        if (gameTimerInterval) clearInterval(gameTimerInterval);
        let html = '<span style="color:var(--green);font-size:16px;font-weight:700;">🎉 All Tests Passed!</span><br><br>';
        results.forEach((r, i) => {
          html += `<span style="color:var(--green);">✅ Test ${i + 1}: Passed</span> — ${r.label}<br>`;
        });
        html += `<br><span style="color:var(--primary);font-weight:700;">🏆 +${ch.xp} XP earned!</span>`;

        // Progression Logic
        if (currentLevel === 'level10') {
          html += '<br><br><span style="color:var(--green);font-size:14px;font-weight:700;">👑 AMAZING! You completed all challenges for this language!</span>';
          document.getElementById('submitBtn').classList.add('hidden');
        } else {
          html += '<br><span style="color:var(--text-muted);font-size:13px;">Great job! Click Next Challenge to proceed. 🔥</span>';
          document.getElementById('submitBtn').classList.add('hidden');
          document.getElementById('nextChallengeBtn').classList.remove('hidden');
        }

        output.innerHTML = html;
      } else {
        let html = '<span style="color:var(--red);font-size:15px;font-weight:700;">❌ Submission Failed</span><br><br>';
        results.forEach((r, i) => {
          if (r.passed) {
            html += `<span style="color:var(--green);">✅ Test ${i + 1}: Passed</span> — ${r.label}<br>`;
          } else if (r.error) {
            html += `<span style="color:var(--red);">❌ Test ${i + 1}: Error</span> — ${r.label}<br>`;
            html += `<span style="color:var(--text-muted);font-size:12px;">   Error: ${r.error}</span><br>`;
          } else {
            html += `<span style="color:var(--red);">❌ Test ${i + 1}: Failed</span> — ${r.label}<br>`;
            html += `<span style="color:var(--text-muted);font-size:12px;">   Got: ${r.got}</span><br>`;
          }
        });
        const passedCount = results.filter(r => r.passed).length;
        html += `<br><span style="color:var(--yellow);font-weight:600;">${passedCount}/${results.length} tests passed</span>`;

        if (consoleLogs && consoleLogs.length > 0) {
          html += '<br><br><span style="color:var(--text-secondary);font-weight:600;">📝 Console Output:</span><br>';
          html += `<div style="background: rgba(0,0,0,0.1); padding: 8px; border-radius: 4px; font-family: monospace; color: var(--text-muted); margin-top: 8px; white-space: pre-wrap;">`;
          html += consoleLogs.join('<br>') + '</div>';
        }

        html += '<br><span style="color:var(--text-muted);font-size:12px;">All tests must pass to submit. Use the Test button first!</span>';
        output.innerHTML = html;
      }
    }, 500);
  });

  document.getElementById('resetBtn').addEventListener('click', () => {
    document.getElementById('codeEditor').value = challenges[currentLang][currentLevel].starter;
    document.getElementById('codeOutput').innerHTML = 'Output will appear here...';
  });

  document.getElementById('hintBtn').addEventListener('click', () => {
    document.getElementById('codeOutput').innerHTML =
      '<span style="color:var(--primary);">' + challenges[currentLang][currentLevel].hint + '</span>';
  });

  // NEXT CHALLENGE button
  document.getElementById('nextChallengeBtn').addEventListener('click', () => {
    const lvlNum = parseInt(currentLevel.replace('level', ''));
    if (lvlNum < 10) {
      loadChallenge('level' + (lvlNum + 1));
    }
  });
}

// ========== LEADERBOARD ==========
function initLeaderboard() {
  const players = [
    { rank: 4, name: 'Nina W.', initials: 'NW', level: 38, xp: '35,200', color: 'linear-gradient(#EC4899,#8B5CF6)' },
    { rank: 5, name: 'David L.', initials: 'DL', level: 35, xp: '32,100', color: 'linear-gradient(#FF7A29,#F59E0B)' },
    { rank: 6, name: 'Priya M.', initials: 'PM', level: 32, xp: '28,700', color: 'linear-gradient(#22C55E,#06B6D4)' },
    { rank: 7, name: 'Tom C.', initials: 'TC', level: 30, xp: '25,400', color: 'linear-gradient(#3B82F6,#8B5CF6)' },
    { rank: 8, name: 'Lisa S.', initials: 'LS', level: 28, xp: '22,000', color: 'linear-gradient(#FF6B6B,#FF7A29)' },
    { rank: 9, name: 'Chris B.', initials: 'CB', level: 25, xp: '19,500', color: 'linear-gradient(#F59E0B,#FF7A29)' },
    { rank: 10, name: 'Aisha R.', initials: 'AR', level: 22, xp: '16,800', color: 'linear-gradient(#06B6D4,#22C55E)' },
  ];

  const table = document.getElementById('leaderboardTable');
  table.innerHTML = players.map(p => `
    <div class="lb-row">
      <div class="lb-rank">${p.rank}</div>
      <div class="avatar avatar-sm" style="background:${p.color};">${p.initials}</div>
      <div class="lb-name">${p.name}</div>
      <div class="lb-level">Lv ${p.level}</div>
      <div class="lb-xp">${p.xp} XP</div>
    </div>
  `).join('');
}

// ========== MULTIPLAYER ==========
let battleTimeout = null;

function startBattle(name) {
  const lobby = document.getElementById('mpLobby');
  const vs = document.getElementById('vsScreen');
  lobby.style.display = 'none';
  vs.classList.add('active');

  let count = 3;
  const countdown = document.getElementById('battleCountdown');
  countdown.textContent = count;

  const interval = setInterval(() => {
    count--;
    countdown.textContent = count;
    if (count <= 0) {
      clearInterval(interval);
      vs.classList.remove('active');
      lobby.style.display = '';
      navigateTo('game');
    }
  }, 1000);

  battleTimeout = interval;
}

function cancelBattle() {
  if (battleTimeout) clearInterval(battleTimeout);
  document.getElementById('vsScreen').classList.remove('active');
  document.getElementById('mpLobby').style.display = '';
}

// ========== DAILY STREAK ==========
function initStreak() {
  // Animate streak count
  const countEl = document.getElementById('streakCount');
  let i = 0;
  const target = 12;
  const interval = setInterval(() => {
    i++;
    countEl.textContent = i;
    if (i >= target) clearInterval(interval);
  }, 80);

  // Heatmap
  const grid = document.getElementById('heatmapGrid');
  if (grid.children.length > 0) return; // Already initialized
  for (let d = 0; d < 35; d++) {
    const cell = document.createElement('div');
    cell.className = 'heatmap-cell';
    const rand = Math.random();
    if (rand > 0.7) cell.classList.add('level-' + Math.ceil(Math.random() * 4));
    grid.appendChild(cell);
  }
}

// ========== COMMUNITY CHAT ==========
const chatData = [
  { name: 'Alex X.', initials: 'AX', color: 'linear-gradient(#F59E0B,#FF7A29)', time: '2m ago', text: 'Just solved the FizzBuzz challenge! 🎉' },
  { name: 'Sarah K.', initials: 'SK', color: 'linear-gradient(#3B82F6,#8B5CF6)', time: '5m ago', text: 'Can anyone help me with CSS Grid? I\'m stuck on it.' },
  { name: 'Mike R.', initials: 'MR', color: 'linear-gradient(#22C55E,#06B6D4)', time: '8m ago', text: 'Just reached Level 30! 🔥🔥🔥' },
  { name: 'Emma P.', initials: 'EP', color: 'linear-gradient(#06B6D4,#3B82F6)', time: '12m ago', text: 'The AI teacher explained loops really well. Recommend trying it!' },
  { name: 'Raj K.', initials: 'RK', color: 'linear-gradient(#F59E0B,#FF7A29)', time: '15m ago', text: 'Anyone want to do a multiplayer battle? Join the Python Speed lobby! ⚔️' },
];

let chatInitialized = false;

function initChat() {
  if (chatInitialized) return;
  chatInitialized = true;

  const container = document.getElementById('chatMessages');
  container.innerHTML = chatData.map(m => `
    <div class="chat-msg">
      <div class="avatar avatar-sm" style="background:${m.color};">${m.initials}</div>
      <div class="chat-msg-content">
        <div class="chat-msg-name">${m.name} <span>${m.time}</span></div>
        <div class="chat-msg-text">${m.text}</div>
      </div>
    </div>
  `).join('');
  container.scrollTop = container.scrollHeight;

  // Send message
  const input = document.getElementById('chatInput');
  const sendBtn = document.getElementById('chatSendBtn');

  function sendMessage() {
    const text = input.value.trim();
    if (!text) return;

    const msg = document.createElement('div');
    msg.className = 'chat-msg';
    msg.innerHTML = `
      <div class="avatar avatar-sm" style="background:linear-gradient(#FF7A29,#FF9F43);">YOU</div>
      <div class="chat-msg-content">
        <div class="chat-msg-name">You <span>Just now</span></div>
        <div class="chat-msg-text">${text}</div>
      </div>
    `;
    container.appendChild(msg);
    container.scrollTop = container.scrollHeight;
    input.value = '';
  }

  sendBtn.addEventListener('click', sendMessage);
  input.addEventListener('keypress', e => {
    if (e.key === 'Enter') sendMessage();
  });

  // Channel switching
  document.querySelectorAll('.channel-item').forEach(ch => {
    ch.addEventListener('click', () => {
      document.querySelectorAll('.channel-item').forEach(c => c.classList.remove('active'));
      ch.classList.add('active');
    });
  });
}

// ========== AI CODE GENERATOR ==========
const codeTemplates = {
  python: {
    'calculator': `# Calculator Function
def calculator(a, b, operation):
    """Perform basic arithmetic operations."""
    operations = {
        'add': a + b,
        'subtract': a - b,
        'multiply': a * b,
        'divide': a / b if b != 0 else 'Error: Division by zero'
    }
    return operations.get(operation, 'Invalid operation')

# Example usage
print(calculator(10, 5, 'add'))       # 15
print(calculator(10, 5, 'multiply'))  # 50
print(calculator(10, 0, 'divide'))    # Error`,

    'todo': `# Todo List Application
class TodoList:
    def __init__(self):
        self.tasks = []
    
    def add_task(self, task):
        self.tasks.append({'task': task, 'done': False})
        print(f"✅ Added: {task}")
    
    def complete_task(self, index):
        if 0 <= index < len(self.tasks):
            self.tasks[index]['done'] = True
            print(f"🎉 Completed: {self.tasks[index]['task']}")
    
    def show_tasks(self):
        for i, t in enumerate(self.tasks):
            status = '✅' if t['done'] else '⬜'
            print(f"{i+1}. {status} {t['task']}")

# Usage
todo = TodoList()
todo.add_task("Learn Python")
todo.add_task("Build a project")
todo.complete_task(0)
todo.show_tasks()`,

    'sorting': `# Bubble Sort Algorithm
def bubble_sort(arr):
    """Sort a list using bubble sort algorithm."""
    n = len(arr)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:
            break
    return arr

# Example
numbers = [64, 34, 25, 12, 22, 11, 90]
print(f"Original: {numbers}")
print(f"Sorted:   {bubble_sort(numbers)}")`,

    'password': `# Password Generator
import random
import string

def generate_password(length=16, use_special=True):
    """Generate a secure random password."""
    chars = string.ascii_letters + string.digits
    if use_special:
        chars += string.punctuation
    
    password = [
        random.choice(string.ascii_uppercase),
        random.choice(string.ascii_lowercase),
        random.choice(string.digits),
    ]
    if use_special:
        password.append(random.choice(string.punctuation))
    
    password += [random.choice(chars) for _ in range(length - len(password))]
    random.shuffle(password)
    return ''.join(password)

# Generate passwords
for i in range(3):
    print(f"Password {i+1}: {generate_password()}")`,

    'default': `# Python Code Generator
def hello_world():
    """A simple greeting function."""
    print("Hello from Code Quest! 🔥")
    print("Start coding your ideas!")

hello_world()`
  },
  javascript: {
    'default': `// JavaScript Code Generator
const greet = (name) => {
  console.log(\`Hello, \${name}! Welcome to Code Quest 🔥\`);
};

const fibonacci = (n) => {
  const seq = [0, 1];
  for (let i = 2; i < n; i++) {
    seq.push(seq[i-1] + seq[i-2]);
  }
  return seq;
};

greet("Developer");
console.log("Fibonacci:", fibonacci(10));`
  },
  html: {
    'default': `<!-- HTML Template -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Awesome Page</title>
  <style>
    body { font-family: sans-serif; padding: 2rem; }
    .card {
      background: linear-gradient(135deg, #FF7A29, #FF9F43);
      color: white;
      padding: 2rem;
      border-radius: 16px;
      max-width: 400px;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>🔥 Hello World!</h1>
    <p>Built with Code Quest!</p>
  </div>
</body>
</html>`
  },
  css: {
    'default': `/* Modern CSS Card Design */
.card {
  background: linear-gradient(135deg, #FF7A29, #FF9F43);
  border-radius: 20px;
  padding: 2rem;
  color: white;
  box-shadow: 0 10px 40px rgba(255, 122, 41, 0.3);
  transition: transform 0.3s ease;
}

.card:hover {
  transform: translateY(-8px) scale(1.02);
}

.card h2 {
  font-size: 1.5rem;
  margin-bottom: 0.5rem;
}

.card p {
  opacity: 0.9;
  line-height: 1.6;
}

/* Animated button */
.btn {
  background: white;
  color: #FF7A29;
  border: none;
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.3s ease;
}

.btn:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 16px rgba(0,0,0,0.15);
}`
  }
};

let selectedAILang = 'python';

function initAIGenerator() {
  // Language selection
  document.querySelectorAll('.ai-lang-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.ai-lang-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedAILang = btn.dataset.lang;
    });
  });

  // Generate
  document.getElementById('generateBtn').addEventListener('click', () => {
    const prompt = document.getElementById('aiPrompt').value.toLowerCase();
    const indicator = document.getElementById('aiTypingIndicator');
    const output = document.getElementById('aiOutputCode');
    const copyBtn = document.getElementById('copyCodeBtn');
    const downloadBtn = document.getElementById('downloadCodeBtn');

    indicator.classList.add('active');
    output.innerHTML = '';
    copyBtn.style.display = 'none';
    downloadBtn.style.display = 'none';

    // Find matching template
    let code = '';
    const langTemplates = codeTemplates[selectedAILang] || codeTemplates.python;
    if (prompt.includes('calculator') || prompt.includes('calc')) code = langTemplates.calculator || langTemplates.default;
    else if (prompt.includes('todo')) code = langTemplates.todo || langTemplates.default;
    else if (prompt.includes('sort')) code = langTemplates.sorting || langTemplates.default;
    else if (prompt.includes('password')) code = langTemplates.password || langTemplates.default;
    else code = langTemplates.default;

    // Typing animation
    let i = 0;
    const typeInterval = setInterval(() => {
      if (i < code.length) {
        output.textContent += code[i];
        i++;
      } else {
        clearInterval(typeInterval);
        indicator.classList.remove('active');
        copyBtn.style.display = 'inline-flex';
        downloadBtn.style.display = 'inline-flex';
      }
    }, 15);
  });

  // Copy
  document.getElementById('copyCodeBtn').addEventListener('click', () => {
    const code = document.getElementById('aiOutputCode').textContent;
    navigator.clipboard.writeText(code).then(() => {
      const btn = document.getElementById('copyCodeBtn');
      btn.textContent = '✅ Copied!';
      setTimeout(() => btn.textContent = '📋 Copy', 2000);
    });
  });

  // Download
  document.getElementById('downloadCodeBtn').addEventListener('click', () => {
    const code = document.getElementById('aiOutputCode').textContent;
    const ext = { python: 'py', javascript: 'js', html: 'html', css: 'css' };
    const blob = new Blob([code], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'code_quest_generated.' + (ext[selectedAILang] || 'txt');
    a.click();
  });

  // Clear
  document.getElementById('clearPrompt').addEventListener('click', () => {
    document.getElementById('aiPrompt').value = '';
    document.getElementById('aiOutputCode').innerHTML = '<span style="color:var(--text-muted);">// Your generated code will appear here...</span>';
    document.getElementById('copyCodeBtn').style.display = 'none';
    document.getElementById('downloadCodeBtn').style.display = 'none';
  });
}

function setPrompt(text) {
  document.getElementById('aiPrompt').value = text;
}

// ========== AI TEACHER ==========
const teacherResponses = {
  'loop': `Great question! 🔁 Loops let you repeat code multiple times.

<strong>Python for loop:</strong>
<pre>for i in range(5):
    print(f"Iteration {i}")

# Output: 0, 1, 2, 3, 4</pre>

<strong>While loop:</strong>
<pre>count = 0
while count < 3:
    print(count)
    count += 1</pre>

The <code>for</code> loop is best when you know how many times to repeat. The <code>while</code> loop keeps going until a condition becomes False.`,

  'function': `Functions are reusable blocks of code! ⚙️

<strong>Python function:</strong>
<pre>def greet(name):
    return f"Hello, {name}!"

message = greet("Coder")
print(message)  # Hello, Coder!</pre>

<strong>Key concepts:</strong>
• <code>def</code> keyword defines a function
• Parameters go in parentheses
• <code>return</code> sends a value back
• Functions help organize and reuse code`,

  'array': `Arrays (called Lists in Python) store multiple values! 📦

<strong>JavaScript Array:</strong>
<pre>const fruits = ["apple", "banana", "cherry"];
console.log(fruits[0]);     // "apple"
console.log(fruits.length); // 3

// Useful methods
fruits.push("date");
fruits.pop();
fruits.map(f => f.toUpperCase());</pre>

<strong>Python List:</strong>
<pre>numbers = [1, 2, 3, 4, 5]
numbers.append(6)
total = sum(numbers)  # 21</pre>`,

  'flexbox': `CSS Flexbox is a layout system! 📐

<pre>.container {
    display: flex;
    justify-content: center;  /* horizontal */
    align-items: center;      /* vertical */
    gap: 16px;
}

.item {
    flex: 1;  /* equal width */
}</pre>

<strong>Key properties:</strong>
• <code>flex-direction</code>: row | column
• <code>justify-content</code>: start | center | space-between
• <code>align-items</code>: start | center | stretch
• <code>flex-wrap</code>: wrap | nowrap`,

  'default': `That's a great question! 🤔 Let me explain...

Programming is all about breaking problems into smaller steps. Here are some tips:

1. <strong>Start simple</strong> — Get basic logic working first
2. <strong>Test often</strong> — Run your code after each change
3. <strong>Read errors</strong> — Error messages tell you what went wrong
4. <strong>Practice daily</strong> — Consistency builds skills faster

Try the challenges in our Play Game section to apply what you learn! 🎮`
};

function initAITeacher() {
  const input = document.getElementById('teacherInput');
  const sendBtn = document.getElementById('teacherSendBtn');

  function sendTeacherMessage() {
    const text = input.value.trim();
    if (!text) return;
    addTeacherMessage(text, 'user');
    input.value = '';

    // Simulate thinking
    setTimeout(() => {
      let response = teacherResponses.default;
      const lower = text.toLowerCase();
      if (lower.includes('loop') || lower.includes('for') || lower.includes('while')) response = teacherResponses.loop;
      else if (lower.includes('function') || lower.includes('def')) response = teacherResponses.function;
      else if (lower.includes('array') || lower.includes('list')) response = teacherResponses.array;
      else if (lower.includes('flex') || lower.includes('css')) response = teacherResponses.flexbox;
      addTeacherMessage(response, 'ai');
    }, 800);
  }

  sendBtn.addEventListener('click', sendTeacherMessage);
  input.addEventListener('keypress', e => {
    if (e.key === 'Enter') sendTeacherMessage();
  });

  document.getElementById('clearChatBtn').addEventListener('click', () => {
    const container = document.getElementById('teacherMessages');
    container.innerHTML = `
      <div class="teacher-msg ai">
        <div class="avatar avatar-sm" style="background:linear-gradient(135deg,#FF7A29,#FF9F43);">🧠</div>
        <div class="msg-bubble">
          👋 Chat cleared! Ask me anything about coding.
        </div>
      </div>
    `;
  });
}

function askTeacher(question) {
  document.getElementById('teacherInput').value = question;
  document.getElementById('teacherSendBtn').click();
}

function addTeacherMessage(content, type) {
  const container = document.getElementById('teacherMessages');
  const msg = document.createElement('div');
  msg.className = `teacher-msg ${type}`;

  if (type === 'ai') {
    msg.innerHTML = `
      <div class="avatar avatar-sm" style="background:linear-gradient(135deg,#FF7A29,#FF9F43);">🧠</div>
      <div class="msg-bubble">${content}</div>
    `;
  } else {
    msg.innerHTML = `
      <div class="avatar avatar-sm" style="background:linear-gradient(135deg,#3B82F6,#8B5CF6);">👤</div>
      <div class="msg-bubble">${content}</div>
    `;
  }

  container.appendChild(msg);
  container.scrollTop = container.scrollHeight;
}

// ========== AUTH ==========
function initAuth() {
  // Tab switching
  document.querySelectorAll('.auth-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.auth-form').forEach(f => f.classList.remove('active'));
      tab.classList.add('active');
      const formId = tab.dataset.tab === 'login' ? 'loginForm' : 'signupForm';
      document.getElementById(formId).classList.add('active');
    });
  });

  // Form submission
  document.getElementById('loginForm').addEventListener('submit', e => {
    e.preventDefault();
    alert('🎉 Login successful! Welcome back to Code Quest!');
  });
  document.getElementById('signupForm').addEventListener('submit', e => {
    e.preventDefault();
    alert('🎉 Account created! Welcome to Code Quest!');
  });
}
